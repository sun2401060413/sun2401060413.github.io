import os
import cv2

os.chdir(os.path.dirname(__file__))

''' Example 2: 视频读入显示保存'''

# 视频读入
# 读入本地视频文件
# cameraCapture = cv2.VideoCapture("MyVideo.mp4")
# 读入本地摄像机视频流
# cameraCapture = cv2.VideoCapture(0)
# 读入网络视频流(RTSP协议)【大雄兔动画片-点播】
# cameraCapture = cv2.VideoCapture("rtsp://184.72.239.149/vod/mp4://BigBuckBunny_175k.mov")
# 读入网络视频流(RTMP协议)【香港卫视-直播】
# cameraCapture = cv2.VideoCapture("rtmp://live.hkstv.hk.lxdns.com/live/hks1")
# 读入网络视频流(HTTP协议)【CCTV1-直播】
cameraCapture = cv2.VideoCapture("http://223.110.242.130:6610/gitv/live1/G_CCTV-1-HQ/1.m3u8")
cv2.namedWindow("display",cv2.WINDOW_NORMAL)

#视频保存
fourcc = cv2.VideoWriter_fourcc('X','V','I','D')                    # 视频编码配置
videoWriter = cv2.VideoWriter('output.mp4', fourcc, 25, (480,320))  # 视频保存配置


while True:
    # 从视频流中读取一帧图像
    success, frame = cameraCapture.read()
    if success:
        # 显示图像
        cv2.imshow("display",frame)
        # 将帧图像添加到视频保存序列中
        img = cv2.resize(frame,(480,320))   # 非必须
        videoWriter.write(img) 
        if cv2.waitKey(1)==27:              # 按'ESC'键后退出程序
            break
    # 视频结束/读取错误后退出
    else:
        break
# 释放writer
videoWriter.release()
