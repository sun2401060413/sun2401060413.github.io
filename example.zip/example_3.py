import os
import cv2
import numpy as np

os.chdir(os.path.dirname(__file__))

''' Example 3: 图像变换'''
# 图像读入
image = cv2.imread("MyPic.png")    # cv2.IMREAD_COLOR
# 色彩空间变换
image_gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
# 尺度变换
image_scale = cv2.resize(image,(320,480))
# 位移
M1 = np.float32([[1,0,100],[0,1,50]])
image_mov = cv2.warpAffine(image,M1,(image.shape[1],image.shape[0]))
# 图像旋转
print(image.shape)
M2 = cv2.getRotationMatrix2D((960,540),10,1)
image_rot = cv2.warpAffine(image,M2,(image.shape[1],image.shape[0]))


# 图像显示
cv2.namedWindow("image",cv2.WINDOW_NORMAL)      # 窗口支持手动调整尺度
cv2.namedWindow("image_gray",cv2.WINDOW_NORMAL) # 窗口支持手动调整尺度
cv2.namedWindow("image_scale")  
cv2.namedWindow("image_mov",cv2.WINDOW_NORMAL)  
cv2.namedWindow("image_rot",cv2.WINDOW_NORMAL)


cv2.imshow("image",image)
cv2.imshow("image_gray",image_gray)
cv2.imshow("image_scale",image_scale)
cv2.imshow("image_mov",image_mov)
cv2.imshow("image_rot",image_rot)


cv2.waitKey()