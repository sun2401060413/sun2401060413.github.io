import os
import cv2

os.chdir(os.path.dirname(__file__))

''' Example：图像读入显示保存'''
# 图像读入
image = cv2.imread("MyPic.png")    # cv2.IMREAD_COLOR
# 直接以灰度图形式载入图像
image_gray = cv2.imread("MyPic.png",cv2.IMREAD_GRAYSCALE)
# 不变
image_unchange = cv2.imread("MyPic.png",cv2.IMREAD_UNCHANGED)

# 图像保存
cv2.imwrite("MyPic.jpg",image_gray)

# 图像显示
cv2.namedWindow("image",cv2.WINDOW_NORMAL)
cv2.namedWindow("image_gray",cv2.WINDOW_NORMAL)
cv2.namedWindow("image_unchange",cv2.WINDOW_NORMAL)
cv2.imshow("image",image)
cv2.imshow("image_gray",image_gray)
cv2.imshow("image_unchange",image_unchange)
cv2.waitKey()
