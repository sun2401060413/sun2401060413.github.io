import os
import cv2
import numpy as np

os.chdir(os.path.dirname(__file__))

''' Example 4: 图像分析'''
# 图像读入
image = cv2.imread("MyPic.png")    # cv2.IMREAD_COLOR
image_gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)

# 图像分割
ret, image_bw = cv2.threshold(image_gray, 127, 255, cv2.THRESH_BINARY)

# 边缘检测
image_canny = cv2.Canny(image_gray, 100, 300)

# Hough变换
minLineLength = 100
maxLineGap = 20
lines = cv2.HoughLinesP(image_canny, 1, np.pi / 180, 100, minLineLength, maxLineGap)
image_hough = image.copy()
for elem in lines:
    x1,y1,x2,y2 = elem[0]
    cv2.line(image_hough, (x1, y1), (x2, y2), (0, 255, 0), 5)
    
# 角点


# 图像显示
cv2.namedWindow("image",cv2.WINDOW_NORMAL)      # 窗口支持手动调整尺度
cv2.namedWindow("image_bw",cv2.WINDOW_NORMAL) # 窗口支持手动调整尺度
cv2.namedWindow("image_canny",cv2.WINDOW_NORMAL) # 窗口支持手动调整尺度
cv2.namedWindow("image_hough",cv2.WINDOW_NORMAL) # 窗口支持手动调整尺度

cv2.imshow("image",image)
cv2.imshow("image_bw",image_bw)
cv2.imshow("image_canny",image_canny)
cv2.imshow("image_hough",image_hough)

cv2.waitKey()