import os
import cv2
import numpy as np

os.chdir(os.path.dirname(__file__))

''' Example 5: 图像绘制'''
# 图像读入
image = cv2.imread("MyPic.png")    # cv2.IMREAD_COLOR
image_gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)

# 创建空图像
# image_process = np.zeros_like(image)
image_process = np.zeros((1080,1920,3),np.uint8)
# 图像赋值
image_process[980:1080,0:1920] = [0,0,255]
image_process[880:980,0:1920] = [0,255,0]
image_process[780:880,0:1920] = [255,0,0]
# 图像复制
image_process[480:780,0:1920] = image[480:780,0:1920]
# 图像数值判断
loc = np.where(image[:,:,2]>200)
image_process[loc] = [0,255,255]

# 图像绘制
# 绘制直线
cv2.line(image_process,(0,0),(100,100),(255,0,255),10)
cv2.line(image_process,(100,100),(0,100),(255,0,255),10)
# 绘制矩形
cv2.rectangle(image_process,(0,150),(100,200),(255,0,255),10)
# 绘制多边形
pts_1 = np.array([[300,150],[350,100],[400,100],[450,150],[400,200],[350,200]], np.int32)
cv2.polylines(image_process,[pts_1],True,(255,255,255),5)
# 填充多边形
pts_2 = np.array([[500,150],[550,100],[600,100],[650,150],[600,200],[550,200]], np.int32)
cv2.fillPoly(image_process,[pts_2],(128,0,255))
# 绘制圆形
cv2.circle(image_process,(200,100),100,(255,255,0),10)
# 绘制文字
cv2.putText(image_process, 'ABCDE_12345', (200,300),cv2.FONT_HERSHEY_SIMPLEX,3,(0,255,0),5)

# 图像显示
cv2.namedWindow("image",cv2.WINDOW_NORMAL)              # 窗口支持手动调整尺度
cv2.namedWindow("image_process",cv2.WINDOW_NORMAL)      # 窗口支持手动调整尺度

cv2.imshow("image",image)
cv2.imshow("image_process",image_process)


cv2.waitKey()