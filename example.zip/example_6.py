import os
import cv2
import numpy as np

os.chdir(os.path.dirname(__file__))

''' Example 6: GUI'''
# 创建画布图像和窗口
img = np.zeros((500, 400, 3), np.uint8)
cv2.namedWindow('image')

# 创建存放绘制点list
points = []

# 定义回调函数
# trackbar 无操作
def trackbar_event(object):
    pass

# 鼠标回调函数
def mouse_event(event,x,y,flags,param):
    global points
    if event == cv2.EVENT_LBUTTONDOWN:
        points = []
    if event == cv2.EVENT_LBUTTONUP:
        pass
    if event==cv2.EVENT_MOUSEMOVE and flags==cv2.EVENT_FLAG_LBUTTON:
        points.append((x,y))
        
# 创建三个开关滑动条RBG
cv2.createTrackbar('R', 'image', 0, 255, trackbar_event)
cv2.createTrackbar('B', 'image', 0, 255, trackbar_event)
cv2.createTrackbar('G', 'image', 0, 255, trackbar_event)

cv2.setMouseCallback("image",mouse_event)

while(True):
    r = cv2.getTrackbarPos('R', 'image')
    g = cv2.getTrackbarPos('G', 'image')
    b = cv2.getTrackbarPos('B', 'image')
    img[:] = [b, g, r]
    for i in range(len(points)-1):
        cv2.line(img,points[i],points[i+1],(255,255,255),5)
    if cv2.waitKey(10)==27: # ESC按键键码为27,即按ESC后退出
        break
    cv2.imshow('image', img)
cv2.destroyAllWindows()

