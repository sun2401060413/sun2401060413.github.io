from absl import app
import absl.flags as app_flags
import os

import alexnet
import densenet121
import densenet161
import densenet169
import inception_v3_2
import inception_v4
import inception_resnet_v2
import resnet_50
import resnet_101
import resnet_152
import vgg16
import vgg19

import flags
import input

# Model configuration
FLAGS = app_flags.FLAGS
app_flags.DEFINE_string("mode", "train", "working mode: train or test")
app_flags.DEFINE_string("filepath", None, "Root path of the classfied images")
app_flags.DEFINE_string("savepath", None, "Root path where you want to save the results")
app_flags.DEFINE_string("weightpath", None, "Root path where your model weights saved to")
app_flags.DEFINE_string("modelname", 'alexnet', "Model structure")
app_flags.DEFINE_string("input_mode", 'original', "original or resized images") # resized mode 中，图像得提前转换好，original mode 现转，两者运行时间不同，resized mode 能快个20s左右... 用处也不大
app_flags.DEFINE_string("extension", None, "Extension of images")
app_flags.DEFINE_float("training_ratio", 0.8, "Training ratio")
app_flags.DEFINE_float("validation_ratio", 0.1, "Validation ratio")
app_flags.DEFINE_integer("size", 224, "Width and height of input images")
app_flags.DEFINE_integer("channels", 3, "Channels of input images")
app_flags.DEFINE_integer("batch_size", 16, "Batch size")
app_flags.DEFINE_integer("epoches", 10, "Epoches")
app_flags.DEFINE_float("lr", None, "Learning rate")             # default : None, 1e-4
app_flags.DEFINE_string("op", None, "optimizer")                # default : None, SGD
app_flags.DEFINE_string("loss", None, "Loss function")          # default : None, categorical_crossentropy,

# # no
# input_dict["mode"] = "train"
# input_dict["filepath"] = None
# input_dict["savepath"] = None
# input_dict["weightpath"] = None
# input_dict["modelname"] = None
# input_dict["input_mode"] = "resized"
# input_dict["extension"] = ['.jpg', '.png']
# input_dict["training_ratio"] = 0.8
# input_dict["validation_ratio"] = 0.1
# input_dict["size"] = 224
# input_dict["channels"] = 3
# input_dict["batch_size"] = 1
# input_dict["epoches"] = 3
# input_dict["lr"] = None
# input_dict["op"] = None
# input_dict["loss"] = None

def main(argv):
    del argv
    # Model configuration
    input_flags = flags.DEFAULT_FLAGS()
    input_dict = input_flags.get_default_dict()
    # input_dict["filepath"] = 'D:/DataSet/WeatherClasifer_Chosen/Resized_Data'
    # input_dict["savepath"] = 'D:/DataSet/WeatherClasifer_Chosen/result/alexnet'
    print(input_dict["savepath"])
    if not os.path.exists(input_dict["savepath"]):
        os.mkdir(input_dict["savepath"])
    print("model parameters:")
    for elem in input_dict:
        print(elem, ":", input_dict[elem])
    input_data = input.INPUT_DATA(input_dict["filepath"],
                                  input_dict["extension"],
                                  input_dict["training_ratio"],
                                  input_dict["validation_ratio"],
                                  (input_dict["size"], input_dict["size"], input_dict["channels"]),
                                  input_dict["input_mode"])
    X_train, Y_train = input_data.get_training_data()
    X_valid, Y_valid = input_data.get_validation_data()
    X_test, Y_test = input_data.get_testing_data()
    input_dict["classname"] = input_data.get_label()

    if input_dict["modelname"] == 'alexnet':
        if input_dict['mode'] == 'train':
            alexnet.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            alexnet.pred(X_test, Y_test, info_dict=input_dict)
    if input_dict["modelname"] == 'resnet_50':
        if input_dict['mode'] == 'train':
            resnet_50.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            resnet_50.pred(X_test, Y_test, info_dict=input_dict)
    if input_dict["modelname"] == 'resnet_101':
        if input_dict['mode'] == 'train':
            resnet_101.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            resnet_101.pred(X_test, Y_test, info_dict=input_dict)
    if input_dict["modelname"] == 'resnet_152':
        if input_dict['mode'] == 'train':
            resnet_152.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            resnet_152.pred(X_test, Y_test, info_dict=input_dict)
    if input_dict["modelname"] == 'densenet_121':
        if input_dict['mode'] == 'train':
            densenet121.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            densenet121.pred(X_test, Y_test, info_dict=input_dict)
    if input_dict["modelname"] == 'densenet_161':
        if input_dict['mode'] == 'train':
            densenet161.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            densenet161.pred(X_test, Y_test, info_dict=input_dict)
    if input_dict["modelname"] == 'densenet_169':
        if input_dict['mode'] == 'train':
            densenet169.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            densenet169.pred(X_test, Y_test, info_dict=input_dict)
    if input_dict["modelname"] == 'vgg_16':
        if input_dict['mode'] == 'train':
            vgg16.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            vgg16.pred(X_test, Y_test, info_dict=input_dict)
    if input_dict["modelname"] == 'vgg_19':
        if input_dict['mode'] == 'train':
            vgg19.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            vgg19.pred(X_test, Y_test, info_dict=input_dict)
    if input_dict["modelname"] == 'inception_v4':
        if input_dict['mode'] == 'train':
            inception_v4.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            inception_v4.pred(X_test, Y_test, info_dict=input_dict)
    if input_dict["modelname"] == 'inception_v3':
        if input_dict['mode'] == 'train':
            inception_v3_2.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            inception_v3_2.pred(X_test, Y_test, info_dict=input_dict)
    if input_dict["modelname"] == 'inception_resnet_v2':
        if input_dict['mode'] == 'train':
            inception_resnet_v2.train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict=input_dict)
        if input_dict['mode'] == 'test':
            inception_resnet_v2.pred(X_test, Y_test, info_dict=input_dict)

    # if input_dict["modelname"] == 'alexnet':
    #     if input_dict['mode'] == 'train':
    #         alexnet.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:10], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         alexnet.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    # if input_dict["modelname"] == 'resnet_50':
    #     if input_dict['mode'] == 'train':
    #         resnet_50.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:10], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         resnet_50.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    # if input_dict["modelname"] == 'resnet_101':
    #     if input_dict['mode'] == 'train':
    #         resnet_101.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:10], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         resnet_101.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    # if input_dict["modelname"] == 'resnet_152':
    #     if input_dict['mode'] == 'train':
    #         resnet_152.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:1000], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         resnet_152.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    # if input_dict["modelname"] == 'densenet_121':
    #     if input_dict['mode'] == 'train':
    #         densenet121.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:1000], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         densenet121.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    # if input_dict["modelname"] == 'densenet_161':
    #     if input_dict['mode'] == 'train':
    #         densenet161.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:1000], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         densenet161.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    # if input_dict["modelname"] == 'densenet_169':
    #     if input_dict['mode'] == 'train':
    #         densenet169.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:1000], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         densenet169.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    # if input_dict["modelname"] == 'vgg_16':
    #     if input_dict['mode'] == 'train':
    #         vgg16.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:1000], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         vgg16.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    # if input_dict["modelname"] == 'vgg_19':
    #     if input_dict['mode'] == 'train':
    #         vgg19.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:1000], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         vgg19.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    # if input_dict["modelname"] == 'inception_v4':
    #     if input_dict['mode'] == 'train':
    #         inception_v4.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:1000], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         inception_v4.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    # if input_dict["modelname"] == 'inception_v3':
    #     if input_dict['mode'] == 'train':
    #         inception_v3_2.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:1000], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         inception_v3_2.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    # if input_dict["modelname"] == 'inception_resnet_v2':
    #     if input_dict['mode'] == 'train':
    #         inception_resnet_v2.train(X_train[0:1000], Y_train[0:1000], X_valid[0:1000], Y_valid[0:1000], X_test[0:1000], Y_test[0:1000], info_dict=input_dict)
    #     if input_dict['mode'] == 'test':
    #         inception_resnet_v2.pred(X_test[0:100], Y_test[0:100], info_dict=input_dict)
    print("Done!")
if __name__ == '__main__':
    app.run(main)