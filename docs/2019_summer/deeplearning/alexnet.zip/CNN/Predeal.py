import tensorflow as tf
import numpy as np
import os
import math

# %%
N_CLASSES = 2
RATIO = 0.15  # take 10% of dataset as validation data
# BATCH_SIZE = 64
# CAPACITY = 2000
# you need to change this to your data directory
train_dir = 'F:/hwb/7 23/7 28/8 22/resize/'


# def get_files(file_dir, ratio):
#     '''
#     注；目前此函数只支持二分类,多分类问题需要修改
#     Args:
#         file_dir: file directory
#     Returns:
#         list of images and labels
#     '''
#     Pass = []
#     label_Pass = []
#     Fail = []
#     label_Fail = []
#     for file in os.listdir(file_dir):
#         name = file.split(sep='.')
#         if name[0] == 'resize_pass':
#             Pass.append(file_dir + file)
#             label_Pass.append(0)
#         else:
#             Fail.append(file_dir + file)
#             label_Fail.append(1)
#     # print(Pass)
#     print('There are %d positive samples\nThere are %d negative samples' % (len(Pass), len(Fail)))
#
#     image_list = np.hstack((Pass, Fail))                # 等价于 np.concatenate(tup, axis=1)
#     label_list = np.hstack((label_Pass, label_Fail))
#
#     temp = np.array([image_list, label_list])
#     temp = temp.transpose()
#     np.random.shuffle(temp)
#
#     all_image_list = temp[:, 0]
#     all_label_list = temp[:, 1]
#
#     n_sample = len(all_label_list)
#     n_val = math.ceil(n_sample * ratio)  # number of validation samples
#     n_train = n_sample - n_val  # number of trainning samples
#
#     tra_images = all_image_list[0:n_train]
#     tra_labels = all_label_list[0:n_train]
#     tra_labels = [int(float(i)) for i in tra_labels]
#     tra_labels = np.array(tra_labels)
#     val_images = all_image_list[n_train:n_sample]
#     val_labels = all_label_list[n_train:n_sample]
#     val_labels = [int(float(i)) for i in val_labels]
#     val_labels=np.array(val_labels)
#
#     return tra_images, tra_labels, val_images, val_labels


#tra_images, tra_labels, val_images, val_labels = get_files(train_dir, 0.15)