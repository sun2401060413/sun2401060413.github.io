from sklearn.metrics import confusion_matrix,  precision_score, recall_score, f1_score, roc_curve, roc_auc_score, classification_report
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
import numpy as np
plt.switch_backend('agg')
class performance_score():
    def __init__(self, score_type = "binary_class"):
        '''
        :param score_type:
                binary_class  # 二分类
                multi_class  # 多分类
                binary_label  # 二标签
                multi_label  # 多标签
        '''
        self.score_type = score_type
    def get_score(self, Y_actual, Y_predict, info_dict = {}):
        part_string = get_part_string(info_dict)
        recorder_name = info_dict["savepath"] + "/record_" + part_string + ".txt"
        confusion_matrix_name = info_dict["savepath"] + "/confusion_matrix_" + part_string + ".png"
        doc = open(recorder_name, 'w')
        # 二分类
        if self.score_type == "binary_class":
            # 计算准确率
            ps = precision_score(Y_actual, Y_predict, average='weighted')
            # 参数average : string, [None, ‘micro’, ‘macro’(default), ‘samples’, ‘weighted’]
            # macro：计算二分类metrics的均值，为每个类给出相同权重的分值。
            # weighted:对于不均衡数量的类来说，计算二分类metrics的平均，通过在每个类的score上进行加权实现。
            # micro：Micro-averaging方法在多标签（multilabel）问题中设置，包含多分类，此时，大类将被忽略。
            # samples：应用在multilabel问题上。它不会计算每个类，相反，它会在评估数据中，
            #          通过计算真实类和预测类的差异的metrics，来求平均（sample_weight-weighted）
            print("precision_score:", ps)

            # 计算召回率
            rc = recall_score(Y_actual, Y_predict, average='weighted')
            print("recall_score:", rc)

            # 计算f1_score
            rc = f1_score(Y_actual, Y_predict, average='weighted')
            print("f1_score:", rc)

            # 计算ROC
            roc = roc_curve(Y_actual, Y_predict)
            print("roc_curve:", roc)

            # 计算roc_auc_score
            roc_auc = roc_auc_score(Y_actual, Y_predict)
            print("roc_auc:", roc_auc)

            # 计算分类报告
            clr = classification_report(Y_actual, Y_predict)
            print("classificaiton_report:\n", clr)

            # 计算混淆矩阵
            cfm = confusion_matrix(Y_actual, Y_predict)
            print("confusion_matrix:\n", cfm)

            plot_confusion_matrix(info_dict["classname"], cfm, confusion_matrix_name)
        # 多分类
        if self.score_type == "multi_class":
            doc = open(recorder_name, 'w')
            # 计算准确率
            ps = precision_score(Y_actual, Y_predict, average='weighted')
            print("precision_score:", ps, file=doc)

            # 计算召回率
            rc = recall_score(Y_actual, Y_predict, average='weighted')
            print("recall_score:", rc, file=doc)

            # 计算f1_score
            rc = f1_score(Y_actual, Y_predict, average='weighted')
            print("f1_score:", rc, file=doc)

            # 计算分类报告
            clr = classification_report(Y_actual, Y_predict)
            print("classificaiton_report:\n", clr, file=doc)

            # 计算混淆矩阵
            cfm = confusion_matrix(Y_actual, Y_predict)
            print("confusion_matrix:\n", cfm, file=doc)

            plot_confusion_matrix(info_dict["classname"], cfm, confusion_matrix_name)
        # 二标签
        if self.score_type == "binary_label":
            # 计算准确率
            ps = precision_score(Y_actual, Y_predict, average='micro')
            # 参数average : string, [None, ‘micro’, ‘macro’(default), ‘samples’, ‘weighted’]
            # micro：Micro-averaging方法在多标签（multilabel）问题中设置，包含多分类，此时，大类将被忽略。
            # samples：应用在multilabel问题上。它不会计算每个类，相反，它会在评估数据中，
            #          通过计算真实类和预测类的差异的metrics，来求平均（sample_weight-weighted）
            print("precision_score:", ps)

            # 计算召回率
            rc = recall_score(Y_actual, Y_predict, average='weighted')
            print("recall_score:", rc)
        # 多标签
        if self.score_type == "multi_label":
            # 计算准确率
            ps = precision_score(Y_actual, Y_predict, average='weighted')
            # 参数average : string, [None, ‘micro’, ‘macro’(default), ‘samples’, ‘weighted’]
            # micro：Micro-averaging方法在多标签（multilabel）问题中设置，包含多分类，此时，大类将被忽略。
            # samples：应用在multilabel问题上。它不会计算每个类，相反，它会在评估数据中，
            #          通过计算真实类和预测类的差异的metrics，来求平均（sample_weight-weighted）
            print("precision_score:", ps)

            # 计算召回率
            rc = recall_score(Y_actual, Y_predict, average='weighted')
            print("recall_score:", rc)
        doc.close()

    def get_pred_score(self, Y_actual, Y_predict, info_dict = {}):
        part_string = get_part_string(info_dict)
        recorder_name = info_dict["savepath"] +"/test"+ "/record_" + part_string + ".txt"
        confusion_matrix_name = info_dict["savepath"] +"/test"+ "/confusion_matrix_" + part_string + ".png"
        doc = open(recorder_name, 'w')
        # 二分类
        if self.score_type == "binary_class":
            # 计算准确率
            ps = precision_score(Y_actual, Y_predict, average='weighted')
            # 参数average : string, [None, ‘micro’, ‘macro’(default), ‘samples’, ‘weighted’]
            # macro：计算二分类metrics的均值，为每个类给出相同权重的分值。
            # weighted:对于不均衡数量的类来说，计算二分类metrics的平均，通过在每个类的score上进行加权实现。
            # micro：Micro-averaging方法在多标签（multilabel）问题中设置，包含多分类，此时，大类将被忽略。
            # samples：应用在multilabel问题上。它不会计算每个类，相反，它会在评估数据中，
            #          通过计算真实类和预测类的差异的metrics，来求平均（sample_weight-weighted）
            print("precision_score:", ps)

            # 计算召回率
            rc = recall_score(Y_actual, Y_predict, average='weighted')
            print("recall_score:", rc)

            # 计算f1_score
            rc = f1_score(Y_actual, Y_predict, average='weighted')
            print("f1_score:", rc)

            # 计算ROC
            roc = roc_curve(Y_actual, Y_predict)
            print("roc_curve:", roc)

            # 计算roc_auc_score
            roc_auc = roc_auc_score(Y_actual, Y_predict)
            print("roc_auc:", roc_auc)

            # 计算分类报告
            clr = classification_report(Y_actual, Y_predict)
            print("classificaiton_report:\n", clr)

            # 计算混淆矩阵
            cfm = confusion_matrix(Y_actual, Y_predict)
            print("confusion_matrix:\n", cfm)

            plot_confusion_matrix(info_dict["classname"], cfm, confusion_matrix_name)
        # 多分类
        if self.score_type == "multi_class":
            doc = open(recorder_name, 'w')
            # 计算准确率
            ps = precision_score(Y_actual, Y_predict, average='weighted')
            print("precision_score:", ps, file=doc)

            # 计算召回率
            rc = recall_score(Y_actual, Y_predict, average='weighted')
            print("recall_score:", rc, file=doc)

            # 计算f1_score
            rc = f1_score(Y_actual, Y_predict, average='weighted')
            print("f1_score:", rc, file=doc)

            # 计算分类报告
            clr = classification_report(Y_actual, Y_predict)
            print("classificaiton_report:\n", clr, file=doc)

            # 计算混淆矩阵
            cfm = confusion_matrix(Y_actual, Y_predict)
            print("confusion_matrix:\n", cfm, file=doc)

            plot_confusion_matrix(info_dict["classname"], cfm, confusion_matrix_name)
        # 二标签
        if self.score_type == "binary_label":
            # 计算准确率
            ps = precision_score(Y_actual, Y_predict, average='micro')
            # 参数average : string, [None, ‘micro’, ‘macro’(default), ‘samples’, ‘weighted’]
            # micro：Micro-averaging方法在多标签（multilabel）问题中设置，包含多分类，此时，大类将被忽略。
            # samples：应用在multilabel问题上。它不会计算每个类，相反，它会在评估数据中，
            #          通过计算真实类和预测类的差异的metrics，来求平均（sample_weight-weighted）
            print("precision_score:", ps)

            # 计算召回率
            rc = recall_score(Y_actual, Y_predict, average='weighted')
            print("recall_score:", rc)
        # 多标签
        if self.score_type == "multi_label":
            # 计算准确率
            ps = precision_score(Y_actual, Y_predict, average='weighted')
            # 参数average : string, [None, ‘micro’, ‘macro’(default), ‘samples’, ‘weighted’]
            # micro：Micro-averaging方法在多标签（multilabel）问题中设置，包含多分类，此时，大类将被忽略。
            # samples：应用在multilabel问题上。它不会计算每个类，相反，它会在评估数据中，
            #          通过计算真实类和预测类的差异的metrics，来求平均（sample_weight-weighted）
            print("precision_score:", ps)

            # 计算召回率
            rc = recall_score(Y_actual, Y_predict, average='weighted')
            print("recall_score:", rc)
        doc.close()



def plot_confusion_matrix(classes, matrix, savename):
    """classes: a list of class names"""
     # Normalize by row
    matrix = matrix.astype(np.float)
    linesum = matrix.sum(1)
    linesum = np.dot(linesum.reshape(-1, 1), np.ones((1, matrix.shape[1])))
    matrix /= linesum
    # plot
    plt.switch_backend('agg')
    fig = plt.figure()
    ax = fig.add_subplot(111)
    cax = ax.matshow(matrix)
    fig.colorbar(cax)
    ax.xaxis.set_major_locator(MultipleLocator(1))
    ax.yaxis.set_major_locator(MultipleLocator(1))
    for i in range(matrix.shape[0]):
        ax.text(i, i, str('%.2f' % (matrix[i, i] * 100)), va='center', ha='center')
    ax.set_xticklabels([''] + classes, rotation=90)
    ax.set_yticklabels([''] + classes)
    # save
    plt.savefig(savename)


def get_part_string(info_dict={}):
    part_string = str(info_dict["batch_size"]) + "_" + str(info_dict["epoches"])
    if "lr" in info_dict.keys():
        part_string = part_string + "_" + str(info_dict["lr"])
    if "op" in info_dict.keys():
        part_string = part_string + "_" + info_dict["op"]
    if "loss" in info_dict.keys():
        part_string = part_string + "_" + info_dict["loss"]
    return part_string