import keras
from keras import backend as K
from keras.optimizers import SGD
from keras.models import load_model
K.set_image_dim_ordering='tf'
import numpy as np
import pandas as pd
import absl.app as app
import loss
import test_performance as tp
import flags
import input
import optimizers_setting
import time
import os


# K.set_session(loss.get_session(0.7))

def alexnet(image_height=224, image_width=224, class_count=None, info_dict={}):
    """keras implementation of the SuperVision NN designed by Alex Krizhevsky et. al.
    NOTE: this implementation deviates from the original design in two ways:
        1) the original was architected to operate distributedly across two systems (this implementation is not distributed)
        2) keras Batch Normalization is used in-place of the original Alexnet's local response normalization
    https://papers.nips.cc/paper/4824-imagenet-classification-with-deep-convolutional-neural-networks.pdf
    http://vision.stanford.edu/teaching/cs231b_spring1415/slides/alexnet_tugce_kyunghee.pdf
    http://image-net.org/challenges/LSVRC/2012/supervision.pdf
    :return: assembled alexnet/supervision keras model
    """

    model = keras.models.Sequential()


    # layer 1 - "filters the 224 x 224 x 3 input image with 96 kernels
    #           of size 11 x 11 x 3 with a stride of 4 pixels"
    model.add(keras.layers.Conv2D(filters=96,
                                  kernel_size=(11, 11),
                                  strides=4,
                                  input_shape=(image_height, image_width, 3),
                                  activation="relu",
                                  padding="same"))
    model.add(keras.layers.BatchNormalization())
    model.add(keras.layers.MaxPool2D(pool_size=(3, 3),
                                     strides=(2, 2)))

    # layer 2 - "256 kernels of size 5 x 5 x 48"
    model.add(keras.layers.Conv2D(filters=256,
                                  kernel_size=(5, 5),
                                  activation="relu",
                                  padding="same"))
    model.add(keras.layers.BatchNormalization())
    model.add(keras.layers.MaxPool2D(pool_size=(3, 3),
                                     strides=(2, 2)))

    # layer 3 - "384 kernels of size 3 x 3 x 256"
    model.add(keras.layers.Conv2D(filters=384,
                                  kernel_size=(3, 3),
                                  activation="relu",
                                  padding="same"))
    # layer 4 - "384 kernels of size 3 x 3 x 192"
    model.add(keras.layers.Conv2D(filters=384,
                                  kernel_size=(3, 3),
                                  activation="relu",
                                  padding="same"))
    # layer 5 - "256 kernels of size 3 x 3 x 192"
    model.add(keras.layers.Conv2D(filters=256,
                                  kernel_size=(3, 3),
                                  activation="relu",
                                  padding="same"))
    model.add(keras.layers.MaxPool2D(pool_size=(3, 3),
                                     strides=(2, 2)))

    # flatten before feeding into FC layers
    model.add(keras.layers.Flatten())

    # fully connected layers
    # "The fully-connected layers have 4096 neurons each."
    # "We use dropout in the first two fully-connected layers..."
    model.add(keras.layers.Dense(units=4096))  # layer 6
    model.add(keras.layers.Dropout(0.5))
    model.add(keras.layers.Dense(units=4096))  # layer 7
    model.add(keras.layers.Dropout(0.5))
    model.add(keras.layers.Dense(units=class_count))  # layer 8

    # output layer is softmax
    model.add(keras.layers.Activation('softmax'))


    # sgd = SGD(lr=1e-4, decay=1e-6, momentum=0.9, nesterov=True)
    opt = optimizers_setting.get_optimizer(info_dict=info_dict)
    model.compile(optimizer=opt, loss='categorical_crossentropy', metrics=['accuracy'])

    model.summary()

    return model

def train(X_train, Y_train, X_valid, Y_valid, X_test, Y_test, info_dict={}):
    print("start training ...")
    # Middle string in the filename of recorder
    part_string = tp.get_part_string(info_dict=info_dict)                            #
    if not os.path.exists(info_dict["savepath"]):
        os.mkdir(info_dict["savepath"])
    # Training process recorder
    recorder_name = info_dict["savepath"] + "/training_log_" + part_string + ".txt"
    doc = open(recorder_name, "w")                                                   #
    for elem in info_dict:
        print(elem, ':', info_dict[elem], file=doc)                                  #
    print('Train on %d samples, validate on %d samples, test on %d samples'%(len(X_train), len(X_valid), len(X_test)), file=doc)

    # Load our model
    model = alexnet(image_height=info_dict["size"],
                    image_width=info_dict["size"],
                    class_count=len(info_dict["classname"]),
                    info_dict=info_dict
                    )

    # Start Fine-tuning W
    time_start = time.time()
    hist = model.fit(X_train, Y_train,
              batch_size=info_dict["batch_size"],
              epochs=info_dict["epoches"],
              shuffle=True,
              verbose=1,                                                           #
              validation_data=(X_valid, Y_valid),
              )
    time_end = time.time()
    print('Totally time cost: %d mins, %d sec'%(int((time_end-time_start)//60), int((time_end-time_start)%60)), file=doc)

    # Make predictions
    predictions_valid = model.predict(X_valid, batch_size=info_dict["batch_size"], verbose=1)

    # Cross-entropy loss score
    score = model.evaluate(X_valid, Y_valid, verbose=0)
    print('Test score:', score[0])
    print('Test score:', score[0], file=doc)            # Record the info on a txtfile
    print('Test accuracy:', score[1])
    print('Test accuracy:', score[1], file=doc)         # Record the info on a txtfile

    # Record the loss and accuracy
    df = pd.DataFrame.from_dict(hist.history)
    csv_savename = info_dict["savepath"] + "/" + "AlexNet_" + part_string + "_loss.csv"
    df.to_csv(csv_savename, encoding='utf-8', index=False)

    # Plot and save the loss_accuracy figure
    fig_savename = info_dict["savepath"] + "/" + "AlexNet_" + part_string + ".png"
    loss.training_vis(hist, fig_savename)

    # Save the model
    model_savename = info_dict["savepath"] + "/" + "AlexNet_" + part_string + "_model.h5"
    model.save(model_savename)

    predictions_valid = model.predict(X_test, batch_size=info_dict["batch_size"], verbose=1)
    Y_predict = np.argmax(predictions_valid, axis=1)  # axis = 1是取行的最大值的索引，0是列的最大值的索引
                                                                                           #
    Y_actual = np.argmax(Y_test, axis=1)

    test_performance = tp.performance_score(score_type="multi_class")                      #
    test_performance.get_score(Y_actual, Y_predict, info_dict)

def pred(X_valid, Y_valid, info_dict={}):
    # Middle string
    part_string = tp.get_part_string(info_dict)

    # Load model
    model_savename = info_dict["savepath"] + "/" + "AlexNet_" + part_string + "_model.h5"
    model = load_model(model_savename)

    predictions_valid = model.predict(X_valid, batch_size=info_dict["batch_size"], verbose=1)
    Y_predict = np.argmax(predictions_valid, axis=1)  # axis = 1是取行的最大值的索引，0是列的最大值的索引

    Y_actual = np.argmax(Y_valid, axis=1)

    test_performance = tp.performance_score(score_type="multi_class")
    test_performance.get_score(Y_actual, Y_predict, info_dict)

def main(argv):

    del argv
    # Model configuration
    # input_flags = flags.DEFAULT_FLAGS()
    # input_dict = input_flags.get_default_dict()
    # input_dict["filepath"] = 'D:/DataSet/WeatherClasifer_Chosen/Resized_Data'
    # input_dict["savepath"] = 'D:/DataSet/WeatherClasifer_Chosen/result/alexnet'

    input_dict = {}
    input_dict["mode"] = "train"
    input_dict["filepath"] = r'H:\yongdu1\xihan\resized'
    input_dict["savepath"] = r'H:\yongdu1\xihan\results'
    input_dict["weightpath"] = 'F:/sz/keras_weights'
    input_dict["batch_size"] = 16
    input_dict["extension"] = [".jpg", ".png"]
    input_dict["training_ratio"] = 0.8
    input_dict["validation_ratio"] = 0.1
    input_dict["size"] = 224
    input_dict["channels"] = 3
    input_dict["input_mode"] = "resized"
    input_dict["epoches"] = 10
    input_dict["classname"] = ["sunny", "cloudy", "rainy", "snowy", "foggy"]

    print("model parameters:")
    for elem in input_dict:
        print(elem, ":", input_dict[elem])
    input_data = input.INPUT_DATA(input_dict["filepath"],
                                  input_dict["extension"],
                                  input_dict["training_ratio"],
                                  input_dict["validation_ratio"],
                                  (input_dict["size"], input_dict["size"], input_dict["channels"]),
                                  input_dict["input_mode"])
    X_train, Y_train = input_data.get_training_data()
    X_valid, Y_valid = input_data.get_validation_data()
    X_test, Y_test = input_data.get_testing_data()
    input_dict["classname"] = input_data.get_label()
    if input_dict['mode'] == 'train':
        train(X_train, Y_train, X_valid, Y_valid,X_test, Y_test, info_dict=input_dict)
    if input_dict['mode'] == 'test':
        pred(X_test, Y_test, info_dict=input_dict)

# --------------------------------------Test Case 1 -------------------------------------
if __name__ == '__main__':
    app.run(main)


# ---------------------------------------Test Case 2 -------------------------------------
# if __name__ == '__main__':
#     # conf is the configuration in training and testing session
#     conf = {   "filepath" : "D:/DataSet/WeatherClasifer_Chosen/Resized_Data",
#                     "savepath": "D:/DataSet/WeatherClasifer_Chosen/result/alexnet",
#                     "extension": [".jpg", ".png"],
#                     "training_ratio": 0.8,
#                     "validation_ratio": 0.1,
#                     "size": (224, 224, 3),
#                     "batch_size": 16,
#                     "epoches": 10,
#                     "lr": 1e-3,
#                     # "op": "SGD",
#                     # "loss": "categorical_crossentropy",
#                     "classname": ["sunny", "cloudy", "rainy", "snowy", "foggy"]
#     }
#     X_train, Y_train, X_valid, Y_valid, X_valid, Y_valid ,_ = input.input_resized(conf["filepath"], conf["extension"], conf["training_ratio"], conf["validation_ratio"], conf["size"])
#     train(X_train[:50], Y_train[:50], X_valid[:10], Y_valid[:10], conf)
#     # test(X_valid, Y_valid, conf)




