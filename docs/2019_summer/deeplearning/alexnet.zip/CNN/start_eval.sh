#!/bin/bash

# Exit immediately if a command exits with a non-zero status.
set -e

# Set up the working environment.
CURRENT_DIR=$(pwd)
WORK_DIR="${CURRENT_DIR}"
echo "CURRENT_DIR=${CURRENT_DIR}"
echo "WORK_DIR=${WORK_DIR}"

cd ..
ROOT=$(pwd)
echo "ROOT=${ROOT}"
# Run model_test first to make sure the PYTHONPATH is correctly set.
# C:/Anaconda3/envs/CV/python.exe "${WORK_DIR}"/model_test.py -v

DATASET="F:/sz/Congestion/Resized_data"
DATASET_ORIGINAL="F:/sz/Congestion/Data"
RESULTS="F:/sz/Congestion/Results"
WEIGHTS="F:/sz/keras_weights"

echo "DATASET=${DATASET}"
echo "RESULTS=${RESULTS}"
echo "WEIGHTS=${WEIGHTS}"

# alexnet

# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/alexnet" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="alexnet" \
  # --input_mode="resized" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=224 \
  # --channels=3 \
  # --batch_size=256 \
  # --epoches=20
  
# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/densenet_121" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="densenet_121" \
  # --input_mode="resized" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=224 \
  # --channels=3 \
  # --batch_size=16 \
  # --epoches=20
 
# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/densenet_161" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="densenet_161" \
  # --input_mode="resized" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=224 \
  # --channels=3 \
  # --batch_size=8 \
  # --epoches=20
  
# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/densenet_169" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="densenet_169" \
  # --input_mode="resized" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=224 \
  # --channels=3 \
  # --batch_size=8 \
  # --epoches=20
  
# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/inception_resnet_v2" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="inception_resnet_v2" \
  # --input_mode="original" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=299\
  # --channels=3 \
  # --batch_size=16 \
  # --epoches=20
  
# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/inception_v3" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="inception_v3" \
  # --input_mode="original" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=299 \
  # --channels=3 \
  # --batch_size=32 \
  # --epoches=20

# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/inception_v4" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="inception_v4" \
  # --input_mode="original" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=299 \
  # --channels=3 \
  # --batch_size=16 \
  # --epoches=20
  
# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/resnet_50" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="resnet_50" \
  # --input_mode="resized" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=224 \
  # --channels=3 \
  # --batch_size=32 \
  # --epoches=20
  
# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/resnet_101" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="resnet_101" \
  # --input_mode="resized" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=224 \
  # --channels=3 \
  # --batch_size=16 \
  # --epoches=20

# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/resnet_152" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="resnet_152" \
  # --input_mode="resized" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=224 \
  # --channels=3 \
  # --batch_size=8 \
  # --epoches=20

# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/vgg_16" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="vgg_16" \
  # --input_mode="resized" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=224 \
  # --channels=3 \
  # --batch_size=32 \
  # --epoches=20
  
# # D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # # --mode="train" \
  # # --filepath="${DATASET}"\
  # # --savepath="${RESULTS}/vgg_16" \
  # # --weightpath="${WEIGHTS}" \
  # # --modelname="vgg_16" \
  # # --input_mode="resized" \
  # # --training_ratio=0.8 \
  # # --validation_ratio=0.1 \
  # # --size=224 \
  # # --channels=3 \
  # # --batch_size=32 \
  # # --epoches=40
  
# D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/vgg_19" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="vgg_19" \
  # --input_mode="resized" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=224 \
  # --channels=3 \
  # --batch_size=16 \
  # --epoches=20
  
# # D:/Anaconda3/envs/deeplearning/python.exe "${WORK_DIR}"/main.py \
  # # --mode="train" \
  # # --filepath="${DATASET}"\
  # # --savepath="${RESULTS}/vgg_19" \
  # # --weightpath="${WEIGHTS}" \
  # # --modelname="vgg_19" \
  # # --input_mode="resized" \
  # # --training_ratio=0.8 \
  # # --validation_ratio=0.1 \
  # # --size=224 \
  # # --channels=3 \
  # # --batch_size=16 \
  # # --epoches=40

#  --op=sgd \
# --lr=0.001
  
# C:/Anaconda3/envs/CV/python.exe "${WORK_DIR}"/main.py \
  # --mode="train" \
  # --filepath="${DATASET}"\
  # --savepath="${RESULTS}/alexnet" \
  # --weightpath="${WEIGHTS}" \
  # --modelname="resnet_50" \
  # --input_mode="original" \
  # --training_ratio=0.8 \
  # --validation_ratio=0.1 \
  # --size=224 \
  # --channels=3 \
  # --batch_size=1 \
  # --epoches=3
  

  
## model_variant：
## alexnet
## densenet_121
## densenet_161
## densenet_169
## inception_resnet_v2
## inception_v3
## inception_v4
## resnet_50
## resnet_101
## resnet_152
## vgg_16
## vgg_19


## optimizers variant:
## sgd		# Stochastic gradient descent optimizer.	lr: float >= 0. Learning rate.
## RMSprop	# RMSProp optimizer.						It is recommended to leave the parameters of this optimizer at their default values (except the learning rate, which can be freely tuned).
## Adagrad	# Adagrad optimizer.						It is recommended to leave the parameters of this optimizer at their default values.
## Adadelta	# Adadelta optimizer.						It is recommended to leave the parameters of this optimizer at their default values.
## Adam		# Adam optimizer.							Default parameters follow those provided in the original paper.
## Adamax	# Adamax optimizer from Adam paper's Section 7.	Default parameters follow those provided in the paper.
## Nadam	# Nesterov Adam optimizer.					Default parameters follow those provided in the paper. It is recommended to leave the parameters of this optimizer at their default values.


