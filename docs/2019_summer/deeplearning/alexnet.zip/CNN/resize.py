

import os
import cv2



# filepath='F:/st/Fail/'
# output_path='F:/st/Together/'
filepath='F:\st\dcache\keras-yolo3-master\VOC2007\JPEGImages_1'
output_path='F:\st\dcache\keras-yolo3-master\VOC2007\JPEGImages/'
def get_image_list(filepath):
    filepath = filepath.replace('\\','/')
    pathinfo = os.walk(filepath,topdown=False)
    filenamelist = []
    for root, dirs, files in pathinfo:
        for elem in files:
            filenamelist.append(root + '/' + elem)
    #filenamelist2 = filenamelist.sort(reverse = False)
    return filenamelist      #图片提取顺序变换。。。。。。。。。。

def image_resize(filenamelist,output_path):
    '''
    :param filenamelist:
    :param output_path:
    :return:
    '''
    for elem in filenamelist:
        f_path, f_name = os.path.split(elem)
        img = cv2.imread(elem)
        resize_img = cv2.resize(img, (32,32) ,interpolation=cv2.INTER_CUBIC)
        cv2.imwrite(output_path+'resize_fail.'+f_name,resize_img)
        #cv2.imwrite(output_path + 'resize_jam' , resize_img)
file1=get_image_list(filepath)
image_resize(file1,output_path)
print('shdh')